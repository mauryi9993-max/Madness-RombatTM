# 🕹️ Madness ROM-bat™

> **La Venganza de la Placa Madre** — Un RPG de trivia por turnos desarrollado en pseudocódigo para PSeInt[cite: 1, 4].

---

## ⚠️ ¡Aviso Importante de Seguridad!
* Este juego es **100% gratuito** y de código abierto[cite: 1]. 
* Solo debe descargarse oficialmente desde **GitHub**. 
* **Si pagaste por este juego, ¡te estafaron!** Si lo descargaste de otra página web, estás en riesgo y los creadores no nos hacemos responsables.

---

## 📜 Sobre el Proyecto
**Madness ROM-bat™** es un proyecto académico desarrollado para la institución **E.S.E.T.P. N° 724** (Materia: Laboratorio de Desarrollo I)[cite: 1, 4]. 
Inspirado en la mítica serie web *Madness Combat*[cite: 2], el juego simula una interfaz de terminal de comandos[cite: 4] donde la Resistencia de Hardware debe infiltrarse en la placa madre para derrotar a **Godowner** (el profesor Carlos Godoy poseído por la IA ChatTPG)[cite: 1, 4].

---

## 🔓 Licencia y Libertad de Código
Este videojuego es de **código abierto y distribución libre**. 
* Puedes editarlo, modificarlo y adaptarlo utilizando el motor de pseudocódigo **PSeInt**[cite: 4].
* No necesitas pedir permiso a los creadores para distribuirlo o compartirlo. 
* El juego pertenece por completo a la comunidad que lo utilice.

---

## 👥 Créditos
* **Autores:** Mauricio Pacheco y Nehuen Lopez[cite: 1, 4]
* **Tutoría / Institución:** E.S.E.T.P. N° 724 (Prof. Agustin Schlapp)[cite: 1]

---
*¡Muchísimas gracias por descargar y jugar a Madness ROM-bat™!* 🚀