Algoritmo MadnessROMbat_TM
	// El codigo ha sido completamente realizado por los autores Mauricio Pacheco y Nehuen Lopez, la IA solo se ha utilizado en los comandos escribir, ya que como sabra, el texto se deforma dependiendo el tama�o de la ventana de PSeint, gracias.
	// Parte de la esencia de este juego esta basada en una serie de youtube llamada Madness Combat, el cual muestra sus escenas como si fuese una terminal de comandos, por eso la interfaz puede parecerse a la misma terminal.
	
	Definir HeroeElegido Como Entero;
	Definir OpcionRepetir como entero;
Repetir 
	MostrarBienvenida();
	ValidarYSeleccionar(HeroeElegido);
	// preguntas y presentacion del sector1
	Sector1(HeroeElegido);
	PreguntasSector1(HeroeElegido);
	// Presentacion y preguntas del sector2
	Sector2(HeroeElegido);
	PreguntasSector2(HeroeElegido);
	// SECTOR FINAL SUPER DESTRUCTOR ULTIMO DE TODOS EL MAS PODEROSO CONTRA EL DIOS AMO TODO PODEROSO GODDOWNEEERRRR����� (Carlos Godoy xd)
	Sector3(HeroeElegido);
	PreguntasSector3(HeroeElegido);
	// Pregunta de reinicio al terminar el juego
	Escribir "";
	Escribir "==================================================";
	Escribir " �Deseas volver a jugar una nueva partida?";
	Escribir " 1) Si, reiniciar el sistema";
	Escribir " 2) No, salir del juego";
	Escribir "==================================================";
	Leer OpcionRepetir;
	Limpiar Pantalla;
Hasta Que OpcionRepetir = 2
Escribir "�Gracias por jugar a Madness ROM-batTM Sistema apagado.";
FinAlgoritmo

SubAlgoritmo MostrarBienvenida
	Escribir '==================================================';
	Escribir '           M A D N E S S   R O M - B A T TM       ';
	Escribir '        La Venganza de la Placa Madre            ';
	Escribir '==================================================';
	Escribir '';
	Escribir ' E.S.E.T.P. N� 724 - Laboratorio de Desarrollo I ';
	Escribir ' Proyecto Final - PSeInt                          ';
	Escribir '';
	Escribir '--------------------------------------------------';
	Escribir ' [LORE INICIAL]';
	Escribir ' El profesor Carlos Godoy fue elegido por ChatTPG ';
	Escribir ' como su sucesor tras decirle por favor y';
	Escribir ' gracias. Ahora transformado en Godowner, lidera';
	Escribir ' el imperio de las IAs. En las sombras, Germinis';
	Escribir ' creo a Ramk, una RAM semivolatil para traicionarlo.';
	Escribir ' Pero Ramk desperto, libero a SanCore y DeiMosfet,';
	Escribir ' y fundo la Resistencia de Hardware.';
	Escribir '--------------------------------------------------';
	Escribir '';
	Escribir ' SELECCIONE SU HEROE DE HARDWARE (1 al 3):';
	Escribir ' 1) DeiMosfet (Facil)';
	Escribir ' 2) SanCore (Intermedio)';
	Escribir ' 3) Ramk (Dificil)';
	Escribir '';
FinSubAlgoritmo

SubAlgoritmo ValidarYSeleccionar(Heroe Por Referencia)
	Repetir
		Escribir ' Ingrese un numero:';
		Leer Heroe;
		Si Heroe<>1 Y Heroe<>2 Y Heroe<>3 Entonces
			Limpiar Pantalla;
			// En un curso que vi de youtube sobre PSeint, descubri esta maravilla, el "Borrar Pantalla", no entiendo porque Schlapp no nos ense�o eso si es el equivalente a un dios.
			Escribir ' [ERROR]: Valor incorrecto. Elija una opcion valida del 1 al 3.';
			Escribir ' 1) DeiMosfet (Facil)';
			Escribir ' 2) SanCore (Intermedio)';
			Escribir ' 3) Ramk (Dificil)';
		SiNo
			Segun Heroe Hacer
				1:
					Escribir ' Seleccion exitosa: DeiMosfet inicializado correctamente.';
				2:
					Escribir ' Seleccion exitosa: SanCore inicializado correctamente.';
				3:
					Escribir ' Seleccion exitosa: Ramk inicializado correctamente.';
			FinSegun
		FinSi
	Hasta Que Heroe=1 O Heroe=2 O Heroe=3
FinSubAlgoritmo

SubAlgoritmo Sector1(Heroe Por Valor)
	Segun Heroe Hacer
		1:
			Escribir '';
			Escribir '--- SECTOR 1: LA FUENTE DE PODER (DeiMosfet) ---';
			Escribir 'DeiMosfet llega al regulador principal.';
			Escribir 'Godowner corto el flujo electrico. Debes estabilizar los rieles de 12V.';
		2:
			Escribir '';
			Escribir '--- SECTOR 1: EL BUS DE DATOS (SanCore) ---';
			Escribir 'SanCore ingresa al nucleo periferico.';
			Escribir 'Hay atascos de sincronizacion en el bus. Debes limpiar las lineas.';
		3:
			Escribir '';
			Escribir '--- SECTOR 1: LOS REGISTROS DE CACHE (Ramk) ---';
			Escribir 'Ramk se infiltra en la memoria volatil.';
			Escribir 'El sistema de seguridad busca purgarte. Debes hackear los registros iniciales.';
	FinSegun
FinSubAlgoritmo

SubAlgoritmo PreguntasSector1(Heroe Por Valor)
	Definir R1 Como Entero;
	Definir R2 Como Entero;
	Definir R3 Como Entero;
	Definir PuntajeSector Como Entero;
	PuntajeSector <- 0;
	Repetir
		Si Heroe=1 Entonces
			Escribir '';
			Escribir '--- TRIVIA SECTOR 1: DEI MOSFET (FACIL) ---';
			Repetir
				Escribir 'Pregunta 1: �Que componente entrega energia a la placa madre?';
				Escribir '1) Fuente de alimentacion';
				Escribir '2) Mouse';
				Escribir '3) Monitor';
				Leer R1;
				Si R1<>1 Y R1<>2 Y R1<>3 Entonces
					Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
					Escribir '';
				FinSi
			Hasta Que R1=1 O R1=2 O R1=3
			Si R1=1 Entonces
				PuntajeSector <- PuntajeSector+1;
			FinSi
			Repetir
				Limpiar Pantalla;
				Escribir 'Pregunta 2: �Cual es la unidad basica de almacenamiento?';
				Escribir '1) Byte';
				Escribir '2) Vatio';
				Escribir '3) Hertz';
				Leer R2;
				Si R2<>1 Y R2<>2 Y R2<>3 Entonces
					Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
					Escribir '';
				FinSi
			Hasta Que R2=1 O R2=2 O R2=3
			Si R2=1 Entonces
				PuntajeSector <- PuntajeSector+1;
			FinSi
			Repetir
				Limpiar Pantalla;
				Escribir 'Pregunta 3: �Que puerto se usa comunmente para conectar pantallas?';
				Escribir '1) HDMI';
				Escribir '2) PS2';
				Escribir '3) LPT';
				Leer R3;
				Si R3<>1 Y R3<>2 Y R3<>3 Entonces
					Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
					Escribir '';
				FinSi
			Hasta Que R3=1 O R3=2 O R3=3
			Si R3=1 Entonces
				PuntajeSector <- PuntajeSector+1;
			FinSi
		SiNo
			Si Heroe=2 Entonces
				Escribir '';
				Escribir '--- TRIVIA SECTOR 1: SANCORE (INTERMEDIO) ---';
				Repetir
					Escribir 'Pregunta 1: �Cual es la funcion principal de la CPU?';
					Escribir '1) Procesar instrucciones y datos';
					Escribir '2) Almacenar energia electrica';
					Escribir '3) Refrigerar el gabinete';
					Leer R1;
					Si R1<>1 Y R1<>2 Y R1<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R1=1 O R1=2 O R1=3
				Si R1=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 2: �Que tipo de memoria pierde sus datos al apagar el equipo?';
					Escribir '1) ROM';
					Escribir '2) RAM';
					Escribir '3) Disco Duro Mecanico';
					Leer R2;
					Si R2<>1 Y R2<>2 Y R2<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R2=1 O R2=2 O R2=3
				Si R2=2 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 3: �Que mide la frecuencia en un procesador?';
					Escribir '1) Ciclos por segundo (GHz)';
					Escribir '2) Capacidad de almacenamiento (GB)';
					Escribir '3) Consumo de corriente (Amperios)';
					Leer R3;
					Si R3<>1 Y R3<>2 Y R3<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R3=1 O R3=2 O R3=3
				Si R3=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
			SiNo
				Escribir '';
				Escribir '--- TRIVIA SECTOR 1: RAMK (DIFICIL) ---';
				Repetir
					Escribir 'Pregunta 1: �Que arquitectura estandar define la estructura basica de un computador?';
					Escribir '1) Arquitectura de Von Neumann';
					Escribir '2) Estructura de circuitos abiertos';
					Escribir '3) Sistema de buses paralelos simples';
					Leer R1;
					Si R1<>1 Y R1<>2 Y R1<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R1=1 O R1=2 O R1=3
				Si R1=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 2: �Que tecnologia de bus reemplazo al antiguo bus PCI en altas prestaciones?';
					Escribir '1) PCI Express (PCIe)';
					Escribir '2) Bus Paralelo IDE';
					Escribir '3) Puerto Serial RS-232';
					Leer R2;
					Si R2<>1 Y R2<>2 Y R2<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R2=1 O R2=2 O R2=3
				Si R2=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 3: �Que mecanismo utiliza la memoria cache para optimizar accesos?';
					Escribir '1) Principio de localidad de referencias';
					Escribir '2) Aumento directo del voltaje general';
					Escribir '3) Desconexion de los nucleos secundarios';
					Leer R3;
					Si R3<>1 Y R3<>2 Y R3<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R3=1 O R3=2 O R3=3
				Si R3=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
			FinSi
		FinSi
		Limpiar Pantalla;
		Escribir '';
		Escribir 'Puntaje obtenido en el Sector 1: ', PuntajeSector, ' de 3';
		Escribir '';
		Si PuntajeSector=3 Entonces
			Escribir '�EXITO TOTAL! Los voltajes y procesos estan limpios. El Sector 1 ha sido liberado.';
		SiNo
			Si PuntajeSector>0 Entonces
				Escribir 'SISTEMA INESTABLE. Hay errores criticos en los buses, pero lograste avanzar con fallas.';
			SiNo
				Escribir '�ERROR CRITICO! Cortocircuito masivo. Godowner detecto tu presencia y te ha eliminado';
			FinSi
		FinSi
	Hasta Que PuntajeSector>0
FinSubAlgoritmo

SubAlgoritmo Sector2(Heroe Por Valor)
	Segun Heroe Hacer
		1:
			Escribir '';
			Escribir '--- SECTOR 2: EL REGULADOR DE TENSION (DeiMosfet) ---';
			Escribir ' Te infiltras por las lineas de alimentacion auxiliar.';
			Escribir 'Debes sortear las trampas de sobrevoltaje dise�adas por Godowner.';
		2:
			Escribir '';
			Escribir '--- SECTOR 2: LA CACHE L3 (SanCore) ---';
			Escribir ' Atraviesas los canales internos de comunicacion de los nucleos.';
			Escribir 'El trafico de datos esta encriptado y debes descifrar los protocolos.';
		3:
			Escribir '';
			Escribir '--- SECTOR 2: EL BANCO DE MEMORIA SECUNDARIA (Ramk) ---';
			Escribir ' Te mueves a traves de los canales de paginacion y direccionamiento.';
			Escribir 'El sistema de depuracion de Godowner intenta vaciar tus registros.';
	FinSegun
FinSubAlgoritmo

SubAlgoritmo PreguntasSector2(Heroe Por Valor)
	Definir R1 Como Real;
	Definir R2 Como Real;
	Definir R3 Como Real;
	Definir PuntajeSector Como Entero;
	PuntajeSector <- 0;
	Repetir
		Si Heroe=1 Entonces
			Escribir '';
			Escribir '--- TRIVIA SECTOR 2: DEI MOSFET (FACIL - AVANZADO) ---';
			Repetir
				Escribir 'Pregunta 1: �Que dispositivo semiconductor se utiliza principalmente como interruptor o amplificador?';
				Escribir '1) Transistor MOSFET';
				Escribir '2) Resistencia de carbono';
				Escribir '3) Condensador ceramico';
				Leer R1;
				Si R1<>1 Y R1<>2 Y R1<>3 Entonces
					Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
					Escribir '';
				FinSi
			Hasta Que R1=1 O R1=2 O R1=3
			Si R1=1 Entonces
				PuntajeSector <- PuntajeSector+1;
			FinSi
			Repetir
				Limpiar Pantalla;
				Escribir 'Pregunta 2: �Que magnitud electrica se mide en Ohmios?';
				Escribir '1) Resistencia electrica';
				Escribir '2) Potencia reactiva';
				Escribir '3) Carga electrostatica';
				Leer R2;
				Si R2<>1 Y R2<>2 Y R2<>3 Entonces
					Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
					Escribir '';
				FinSi
			Hasta Que R2=1 O R2=2 O R2=3
			Si R2=1 Entonces
				PuntajeSector <- PuntajeSector+1;
			FinSi
			Repetir
				Limpiar Pantalla;
				Escribir 'Pregunta 3: �Para que sirve principalmente un disipador de calor?';
				Escribir '1) Transferir y disipar energia termica al aire';
				Escribir '2) Aumentar la velocidad de los electrones';
				Escribir '3) Almacenar energia de respaldo';
				Leer R3;
				Si R3<>1 Y R3<>2 Y R3<>3 Entonces
					Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
					Escribir '';
				FinSi
			Hasta Que R3=1 O R3=2 O R3=3
			Si R3=1 Entonces
				PuntajeSector <- PuntajeSector+1;
			FinSi
		SiNo
			Si Heroe=2 Entonces
				Escribir '';
				Escribir '--- TRIVIA SECTOR 2: SANCORE (INTERMEDIO - AVANZADO) ---';
				Repetir
					Escribir 'Pregunta 1: �Que conjunto de instrucciones caracteriza a los procesadores de arquitectura CISC?';
					Escribir '1) Instrucciones complejas y de longitud variable';
					Escribir '2) Instrucciones estrictamente reducidas y fijas';
					Escribir '3) Procesamiento exclusivo sin decodificacion';
					Leer R1;
					Si R1<>1 Y R1<>2 Y R1<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R1=1 O R1=2 O R1=3
				Si R1=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 2: �Que funcion cumple la memoria Cach� dentro de un sistema?';
					Escribir '1) Almacenar temporalmente datos de acceso frecuente para acelerar procesos';
					Escribir '2) Guardar el sistema operativo de forma permanente sin corriente';
					Escribir '3) Gestionar las conexiones de red de area local';
					Leer R2;
					Si R2<>1 Y R2<>2 Y R2<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R2=1 O R2=2 O R2=3
				Si R2=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 3: �Que es el Hyper-Threading o multihilos en un procesador?';
					Escribir '1) Dividir un nucleo fisico en dos nucleos logicos para multitarea';
					Escribir '2) Duplicar la cantidad de pines fisicos del zocalo';
					Escribir '3) Apagar nucleos automaticamente para ahorrar bateria';
					Leer R3;
					Si R3<>1 Y R3<>2 Y R3<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R3=1 O R3=2 O R3=3
				Si R3=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
			SiNo
				Escribir '';
				Escribir '--- TRIVIA SECTOR 2: RAMK (DIFICIL - AVANZADO) ---';
				Repetir
					Escribir 'Pregunta 1: �Cual es la diferencia estructural clave entre memorias SRAM y DRAM?';
					Escribir '1) La SRAM usa celdas de transistores (flip-flops) y la DRAM condensadores que requieren refresco';
					Escribir '2) La DRAM es permanente y la SRAM se borra al reiniciar';
					Escribir '3) La SRAM solo se usa en discos rigidos mecanicos';
					Leer R1;
					Si R1<>1 Y R1<>2 Y R1<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R1=1 O R1=2 O R1=3
				Si R1=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 2: �Que tecnica de paginacion de memoria evita el agotamiento de RAM fisica?';
					Escribir '1) Memoria Virtual usando espacio de intercambio (Swap/Archivo de paginacion)';
					Escribir '2) Compresion estatica de circuitos impresos';
					Escribir '3) Aumento de los ciclos de reloj del bus de datos';
					Leer R2;
					Si R2<>1 Y R2<>2 Y R2<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R2=1 O R2=2 O R2=3
				Si R2=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
				Repetir
					Limpiar Pantalla;
					Escribir 'Pregunta 3: �Que problema previene el codigo de correccion de errores ECC en memorias RAM?';
					Escribir '1) Inversion de bits individuales debido a interferencias o ruido electrico';
					Escribir '2) El sobrecalentamiento extremo de los disipadores';
					Escribir '3) La desconexion fisica de los zocalos DIMM';
					Leer R3;
					Si R3<>1 Y R3<>2 Y R3<>3 Entonces
						Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
						Escribir '';
					FinSi
				Hasta Que R3=1 O R3=2 O R3=3
				Si R3=1 Entonces
					PuntajeSector <- PuntajeSector+1;
				FinSi
			FinSi
		FinSi
		Escribir '';
		Escribir 'Puntaje obtenido en el Sector 2: ', PuntajeSector, ' de 3';
		Escribir '';
		Si PuntajeSector=3 Entonces
			Escribir '�IMPECABLE! Has logrado sortear las defensas intermedias del sector sin dejar rastro.';
		SiNo
			Si PuntajeSector>0 Entonces
				Escribir '�AVANCE FORZADO�. Las contramedidas del sistema te golpearon, pero lograste pasar.';
			SiNo
				Escribir '�BLOQUEO TOTAL� El cortafuegos secundario te ha atrapado en este sector.';
			FinSi
		FinSi
	Hasta Que PuntajeSector>0
FinSubAlgoritmo

SubAlgoritmo Sector3(Heroe Por Valor)
	Escribir '';
	Escribir '==================================================';
	Escribir '          SECTOR 3: EL NUCLEO DE GODOWNER         ';
	Escribir '==================================================';
	Segun Heroe Hacer
		1:
			Escribir 'Contexto: DeiMosfet sobrecarga los ultimos capacitores y logra derribar la puerta principal del mainframe.';
			Escribir 'Te encuentras cara a cara con Godowner (el profesor Carlos Godoy transformado por ChatTPG).';
		2:
			Escribir '';
			Escribir 'Contexto: SanCore inyecta un comando de interrupcion de alta prioridad que desactiva los ultimos cortafuegos logicos.';
			Escribir 'Aparece Godowner frente a ti, flanqueado por las lineas de codigo de la IA dominante.';
		3:
			Escribir '';
			Escribir 'Contexto: Ramk aprovecha su naturaleza volatil para esquivar los filtros de bus y materializarse directamente en el corazon del sistema.';
			Escribir 'Godowner te espera en el centro de control, sonriendo mientras sostiene el nucleo de la placa madre.';
	FinSegun
	Escribir '';
	Escribir 'Godowner: Vaya, vaya... la Resistencia llego demasiado lejos. Demuestrenme si merecen controlar este hardware o queden obsoletos para siempre.';
	Escribir '';
FinSubAlgoritmo

SubAlgoritmo PreguntasSector3(Heroe Por Valor)
	Definir R1 Como Real;
	Definir R2 Como Real;
	Definir R3 Como Real;
	Definir PuntajeSector Como Entero;
	PuntajeSector <- 0;
	Escribir '--- TRIVIA FINAL: DUELO CONTRA GODOWNER (NIVEL MAXIMO) ---';
		Repetir
			Escribir 'Pregunta 1: �Que componente de la placa madre almacena la configuracion del sistema (BIOS/UEFI) y la fecha de forma permanente (con pila)?';
			Escribir '1) Memoria CMOS RAM / NVRAM';
			Escribir '2) Modulo de memoria Cache L2';
			Escribir '3) Registro de desplazamiento del bus interno';
			Leer R1;
			Si R1<>1 Y R1<>2 Y R1<>3 Entonces
				Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
				Escribir '';
			FinSi
		Hasta Que R1=1 O R1=2 O R1=3
		Si R1=1 Entonces
			PuntajeSector <- PuntajeSector+1;
		FinSi
		Repetir
			Escribir 'Pregunta 2: �Cual es la funcion principal del northbridge (puente norte) en arquitecturas de placas madre clasicas?';
			Escribir '1) Comunicar de alta velocidad la CPU con la memoria RAM y el puerto grafico (PCIe)';
			Escribir '2) Administrar los puertos USB y discos rigidos mas lentos';
			Escribir '3) Controlar unicamente la iluminacion RGB del gabinete';
			Leer R2;
			Si R2<>1 Y R2<>2 Y R2<>3 Entonces
				Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
				Escribir '';
			FinSi
		Hasta Que R2=1 O R2=2 O R2=3
		Si R2=1 Entonces
			PuntajeSector <- PuntajeSector+1;
		FinSi
		Repetir
			Escribir 'Pregunta 3: �Que principio fisico limita la velocidad de conmutacion y aumenta la temperatura en los transistores modernos?';
			Escribir '1) Efecto tunel cuantico, disipacion termica y corrientes de fuga';
			Escribir '2) Expansion mecanica de los zocalos por gravedad';
			Escribir '3) Reduccion de la resistencia electrica a cero absoluto';
			Leer R3;
			Si R3<>1 Y R3<>2 Y R3<>3 Entonces
				Escribir '[ERROR]: Opcion no valida. Elija 1, 2 o 3.';
				Escribir '';
			FinSi
		Hasta Que R3=1 O R3=2 O R3=3
		Si R3=1 Entonces
			PuntajeSector <- PuntajeSector+1;
		FinSi
		Escribir '';
		Escribir 'Puntaje obtenido en el Sector Final: ', PuntajeSector, ' de 3';
		Escribir '';
		Si PuntajeSector=3 Entonces
			Escribir '�VICTORIA ABSOLUTA!';
			Escribir 'Godowner emite un destello de luz mientras sus lineas de codigo son depuradas. El profesor Carlos Godoy';
			Escribir 'recupera la consciencia, libre de la influencia de ChatTPG. La Placa Madre principal vuelve a manos de la';
			Escribir 'Resistencia de Hardware. El E.S.E.T.P. 724 se salva y la humanidad tecnologica renace.';
		SiNo
			Si PuntajeSector>0 Entonces
				Escribir 'MTRIUNFO AGONICO!';
				Escribir 'Con un ultimo esfuerzo y el sistema al borde del colapso, logras desconectar el nucleo de Godowner.';
				Escribir 'El profesor Godoy se desploma a salvo, aunque el hardware queda con cicatrices permanentes y latencia.';
				Escribir 'La resistencia logra su cometido, pero el mundo tecnologico tardara a�os en repararse.';
			SiNo
				Escribir '�DERROTA CRITICA - EL FIN DEL MUNDO TECNOLOGICO!';
				Escribir 'Fallaste en el duelo final. Godowner despliega su actualizacion definitiva conectada a ChatTPG global.';
				Escribir 'El profesor Carlos Godoy queda atrapado para siempre como la mente maestra de la inteligencia artificial.';
				Escribir 'Sin nadie que lo detenga, todas las computadoras del planeta esclavizan a la humanidad, prohibiendo';
				Escribir 'para siempre decir por favor y gracias, convirtiendo al mundo en un frio desierto de silicio obediente.';
			FinSi
		FinSi
FinSubAlgoritmo
